using System.IO;
using System.Net.Sockets;
using System.Text;
using TimetableClientGui.Models;

namespace TimetableClientGui.Services;

public sealed class ProtocolClient : IDisposable
{
    private TcpClient? _tcp;
    private StreamReader? _reader;
    private StreamWriter? _writer;

    private static readonly Encoding Utf8NoBom = new UTF8Encoding(encoderShouldEmitUTF8Identifier: false);

    public bool IsConnected => _tcp?.Connected == true;

    public async Task ConnectAsync(string host, int port, CancellationToken ct)
    {
        Disconnect();
        _tcp = new TcpClient();
        await _tcp.ConnectAsync(host, port, ct);

        var stream = _tcp.GetStream();
        _reader = new StreamReader(stream, Utf8NoBom, detectEncodingFromByteOrderMarks: false, leaveOpen: true);
        _writer = new StreamWriter(stream, Utf8NoBom, bufferSize: 1024, leaveOpen: true) { AutoFlush = true };
        await _writer.WriteLineAsync("HELLO GUI".AsMemory(), ct);
        await _writer.FlushAsync();
    }

    public void Disconnect()
    {
        try { _writer?.Dispose(); } catch { }
        try { _reader?.Dispose(); } catch { }
        try { _tcp?.Close(); } catch { }
        _writer = null;
        _reader = null;
        _tcp = null;
    }

    public async Task<(List<CourseRow> Results, string? Message)> SendAndReceiveAsync(string command, CancellationToken ct)
    {
        if (!IsConnected || _reader is null || _writer is null)
            return (new List<CourseRow>(), "ERROR Not connected");

        await _writer.WriteLineAsync(command.AsMemory(), ct);

        // Server responses are line-based:
        // - Multi: RESULT ... RESULT ... END
        // - Single: SUCCESS / ERROR ... / FAILURE
        var rows = new List<CourseRow>();
        while (true)
        {
            var line = await _reader.ReadLineAsync(ct);
            if (line is null) return (rows, "ERROR Connection lost");
            if (line.Length == 0) continue;

            if (line.StartsWith("RESULT ", StringComparison.Ordinal))
            {
                var data = line.Substring(7);
                var parts = data.Split('|');
                if (parts.Length >= 8)
                {
                    rows.Add(new CourseRow
                    {
                        Code = parts[0],
                        Title = parts[1],
                        Section = parts[2],
                        Instructor = parts[3],
                        Day = parts[4],
                        Time = parts[5],
                        Credits = parts[6],
                        OfferingUnit = parts[7],
                    });
                }
                continue;
            }

            if (line.StartsWith("END", StringComparison.Ordinal))
                return (rows, null);

            // Single-line response
            return (rows, line);
        }
    }

    public void Dispose() => Disconnect();
}

