using System.Windows;

namespace TimetableClientGui;

public partial class App : Application
{
}

