namespace TimetableClientGui.Models;

public sealed class CourseRow
{
    public string Code { get; set; } = "";
    public string Title { get; set; } = "";
    public string Section { get; set; } = "";
    public string Instructor { get; set; } = "";
    public string Day { get; set; } = "";
    public string Time { get; set; } = "";
    public string Credits { get; set; } = "";
    public string OfferingUnit { get; set; } = "";
}

