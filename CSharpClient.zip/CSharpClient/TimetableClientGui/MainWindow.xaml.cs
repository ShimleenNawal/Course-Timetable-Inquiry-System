using System.Collections.ObjectModel;
using System.Globalization;
using System.Windows;
using TimetableClientGui.Models;
using TimetableClientGui.Services;

namespace TimetableClientGui;

public partial class MainWindow : Window
{
    private readonly ProtocolClient _client = new();

    private readonly ObservableCollection<CourseRow> _studentRows = new();
    private readonly ObservableCollection<CourseRow> _adminRows = new();

    public MainWindow()
    {
        InitializeComponent();
        ResultsGrid.ItemsSource = _studentRows;
        AdminResultsGrid.ItemsSource = _adminRows;
        UpdFieldBox.SelectedIndex = 0;
    }

    private void SetStatus(string text) => StatusText.Text = text;

    private bool TryGetPort(out int port)
    {
        port = 0;
        if (!int.TryParse(PortBox.Text.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out port))
        {
            SetStatus("Invalid port.");
            return false;
        }
        if (port <= 0 || port > 65535)
        {
            SetStatus("Port must be 1-65535.");
            return false;
        }
        return true;
    }

    private async Task RunCommandToGridAsync(string cmd, ObservableCollection<CourseRow> target)
    {
        SetStatus("Sending: " + cmd);
        var (results, message) = await _client.SendAndReceiveAsync(cmd, CancellationToken.None);

        target.Clear();
        foreach (var row in results) target.Add(row);

        if (message is null)
        {
            SetStatus(results.Count > 0 ? $"OK ({results.Count} result(s))" : "OK");
        }
        else
        {
            SetStatus(message);
            if (results.Count == 0 && (message.StartsWith("SUCCESS", StringComparison.Ordinal) ||
                                       message.StartsWith("ERROR", StringComparison.Ordinal) ||
                                       message.StartsWith("FAILURE", StringComparison.Ordinal)))
            {
                MessageBox.Show(this, message, "Server response", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
    }

    private void UpdateConnUi()
    {
        var connected = _client.IsConnected;
        ConnStatus.Text = connected ? "ONLINE" : "OFFLINE";
        ConnectBtn.IsEnabled = !connected;
        DisconnectBtn.IsEnabled = connected;
    }

    private async void ConnectBtn_Click(object sender, RoutedEventArgs e)
    {
        if (!TryGetPort(out var port)) return;
        var host = HostBox.Text.Trim();
        if (host.Length == 0) { SetStatus("Host is required."); return; }

        try
        {
            SetStatus("Connecting...");
            await _client.ConnectAsync(host, port, CancellationToken.None);
            SetStatus($"Connected to {host}:{port}");
        }
        catch (Exception ex)
        {
            SetStatus("Connect failed: " + ex.Message);
        }
        finally
        {
            UpdateConnUi();
        }
    }

    private void DisconnectBtn_Click(object sender, RoutedEventArgs e)
    {
        _client.Disconnect();
        UpdateConnUi();
        SetStatus("Disconnected.");
    }

    private async void ViewAll_Click(object sender, RoutedEventArgs e)
        => await RunCommandToGridAsync("VIEW_ALL", _studentRows);

    private async void Query_Click(object sender, RoutedEventArgs e)
    {
        var code = QueryCodeBox.Text.Trim();
        if (code.Length == 0) { SetStatus("Enter a course code."); return; }
        await RunCommandToGridAsync("QUERY " + code, _studentRows);
    }

    private async void SearchInstructor_Click(object sender, RoutedEventArgs e)
    {
        var name = InstructorBox.Text.Trim();
        if (name.Length == 0) { SetStatus("Enter an instructor name."); return; }
        await RunCommandToGridAsync("SEARCH_INSTRUCTOR " + name, _studentRows);
    }

    private async void AdminLogin_Click(object sender, RoutedEventArgs e)
    {
        var u = AdminUserBox.Text.Trim();
        var p = AdminPassBox.Password;
        if (u.Length == 0 || p.Length == 0) { SetStatus("Enter username and password."); return; }
        await RunCommandToGridAsync("LOGIN " + u + " " + p, _adminRows);
    }

    private async void AdminLogout_Click(object sender, RoutedEventArgs e)
        => await RunCommandToGridAsync("LOGOUT", _adminRows);

    private async void AdminAdd_Click(object sender, RoutedEventArgs e)
    {
        var code = AddCodeBox.Text.Trim();
        var title = AddTitleBox.Text.Trim();
        var section = AddSectionBox.Text.Trim();
        var instructor = AddInstructorBox.Text.Trim();
        var day = AddDayBox.Text.Trim();
        var time = AddTimeBox.Text.Trim();
        var credits = AddCreditsBox.Text.Trim();
        var offeringUnit = AddOfferingUnitBox.Text.Trim();

        if (new[] { code, title, section, instructor, day, time, credits, offeringUnit }.Any(s => s.Length == 0))
        {
            SetStatus("All ADD fields are required.");
            return;
        }

        var cmd = "ADD " + string.Join("|", code, title, section, instructor, day, time, credits, offeringUnit);
        await RunCommandToGridAsync(cmd, _adminRows);
    }

    private async void AdminUpdate_Click(object sender, RoutedEventArgs e)
    {
        var code = UpdCodeBox.Text.Trim();
        var value = UpdValueBox.Text.Trim();
        if (code.Length == 0 || value.Length == 0) { SetStatus("Code and Value are required."); return; }

        var fieldItem = UpdFieldBox.SelectedItem as System.Windows.Controls.ComboBoxItem;
        var field = (fieldItem?.Content?.ToString() ?? "").Trim();
        if (field.Length == 0) { SetStatus("Select a field."); return; }

        await RunCommandToGridAsync($"UPDATE {code} {field} {value}", _adminRows);
    }

    private async void AdminDelete_Click(object sender, RoutedEventArgs e)
    {
        var code = DelCodeBox.Text.Trim();
        if (code.Length == 0) { SetStatus("Enter a code to delete."); return; }

        if (MessageBox.Show(this, $"Delete {code}?", "Confirm delete", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
            return;

        await RunCommandToGridAsync("DELETE " + code, _adminRows);
    }

    protected override void OnClosed(EventArgs e)
    {
        _client.Dispose();
        base.OnClosed(e);
    }
}

